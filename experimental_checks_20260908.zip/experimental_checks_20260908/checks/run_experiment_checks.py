#!/usr/bin/env python3
"""Measure the fixed, finite validation suite on Linux; never a conductor sweep.

Usage: python3 run_experiment_checks.py --gp /path/to/gp
Fresh GP processes run sequentially with nbthreads=1 and a 256,000,000-byte
initial PARI stack. os.wait4 provides each child's own CPU time and maximum
resident set size (KiB on Linux). Wall time includes process startup, parsing,
verification, and output. No classical-polynomial speed comparison is made.
"""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent
CASES = [
    ('11a1_construct', 'construct_and_verify11.gp',
     'F=construct_and_verify11();exp_emit_coefficients(F);', 'F11', 12, 1),
    ('38a1_verify', 'verify38_certificate.gp',
     'R=verify38_certificate();exp_emit_coefficients(cert38_polynomial());', 'F38', 60, 6),
    ('389a1_semitrace', 'verify389_certificate.gp',
     'R=verify389_certificate();', None, 390, 40),
    ('46a1_yang', 'verify46_yang_certificate.gp', '', None, 72, 5),
    ('91b1_polynomial', 'verify91b1_polynomial.gp', '', None, None, None),
]
EMITTER = r'''
exp_emit_coefficients(F)={
  my(X=variable(F),J=variables(F)[2],v=List(),c);
  for(k=0,poldegree(F,X),for(l=0,poldegree(F,J),
    c=polcoeff(polcoeff(F,k,X),l,J);
    if(c!=0,if(type(c)!="t_INT",error("nonintegral coefficient"));
      listput(v,[k,l,Str(c)]))
  ));
  print("COEFFICIENTS_JSON ",Vec(v));
};
'''

def metrics(label, terms, mu, degree):
    entries = [(int(k), int(l), int(c)) for k, l, c in terms]
    entries.sort()
    content = math.gcd(*(c for _, _, c in entries))
    sign = 1 if entries[-1][2] > 0 else -1
    triples = [[k,l,str(sign*c//content)] for k,l,c in entries]
    encoded = json.dumps(triples, ensure_ascii=True, separators=(',',':')).encode('ascii')
    target = BASE/'data'/f'{label}_canonical.json'
    target.write_bytes(encoded)
    K=max(k for k,l,c in triples);L=max(l for k,l,c in triples)
    assert mu % K == 0 and (2*degree) % L == 0 and mu//K == 2*degree//L
    return dict(polynomial=label,mu=mu,d=degree,K=K,L=L,r=mu//K,
                nonzero_terms=len(triples),max_decimal_digits=max(len(c.lstrip('-')) for k,l,c in triples),
                canonical_bytes=len(encoded),sha256=hashlib.sha256(encoded).hexdigest())

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--gp',default='gp')
    ap.add_argument('--timeout',type=float,default=300)
    args=ap.parse_args()
    if platform.system()!='Linux':
        raise SystemExit('RSS units in this runner are specified for Linux; run GP checks directly elsewhere.')
    import shutil
    gp=shutil.which(args.gp)
    if gp is None:raise SystemExit('GP executable not found')
    (BASE/'results').mkdir(exist_ok=True);(BASE/'data').mkdir(exist_ok=True)
    version_result=subprocess.run([gp,'--version'],capture_output=True,text=True,check=True)
    version=(version_result.stdout+version_result.stderr).strip()
    env={'platform':platform.platform(),'cpu_model':next((l.split(':',1)[1].strip() for l in Path('/proc/cpuinfo').read_text().splitlines() if l.startswith('model name')),None),
         'gp_version':version,'gp_sha256':hashlib.sha256(Path(gp).read_bytes()).hexdigest(),
         'initial_pari_stack_bytes':256000000,'gp_nbthreads':1,'repetitions':1,
         'timestamp_utc':datetime.now(timezone.utc).isoformat(),
         'wall_clock_poll_seconds':0.01,
         'cache_state':'not controlled','host_load':'not controlled',
         'scope':'fresh GP process, including parsing, checks and output',
         'measurement':'monotonic wall clock; per-process os.wait4 rusage; Linux ru_maxrss in KiB',
         'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text().strip() if Path('/sys/fs/cgroup/cpu.max').exists() else None,
         'memory_limit_bytes':Path('/sys/fs/cgroup/memory.max').read_text().strip() if Path('/sys/fs/cgroup/memory.max').exists() else None}
    rows=[];poly=[]
    for name,script,call,label,mu,degree in CASES:
        driver=BASE/'results'/f'{name}_driver.gp'
        driver.write_text('default(nbthreads,1);\n'+EMITTER+'\n'
            +f'read("{script}");\n'+call+'\n'
            +'print("EXPERIMENT_CHECK_COMPLETED");\nquit\n')
        logpath=BASE/'results'/f'{name}.log'
        start=time.monotonic();timedout=False
        with logpath.open('wb') as log:
            proc=subprocess.Popen([gp,'-fq','-s','256000000',str(driver)],cwd=BASE,
                 stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            while True:
                pid,status,usage=os.wait4(proc.pid,os.WNOHANG)
                if pid:break
                if time.monotonic()-start>args.timeout:
                    timedout=True;os.killpg(proc.pid,signal.SIGKILL)
                    pid,status,usage=os.wait4(proc.pid,0);break
                time.sleep(.01)
            elapsed=time.monotonic()-start
            proc.returncode=os.waitstatus_to_exitcode(status)
        log=logpath.read_text(errors='replace')
        okay=proc.returncode==0 and 'EXPERIMENT_CHECK_COMPLETED' in log and '***' not in log
        state='TIMEOUT' if timedout else ('PASS' if okay else 'FAILED')
        row=dict(task=name,status=state,wall_seconds=round(elapsed,6),
                 user_seconds=round(usage.ru_utime,6),system_seconds=round(usage.ru_stime,6),
                 max_rss_KiB=usage.ru_maxrss,exit_code=proc.returncode)
        rows.append(row);print(json.dumps(row),flush=True)
        if label and okay:
            payload=next(l[len('COEFFICIENTS_JSON '):] for l in log.splitlines() if l.startswith('COEFFICIENTS_JSON '))
            poly.append(metrics(label,json.loads(payload),mu,degree))
    record={'environment':env,'measurements':rows,'polynomial_metrics':poly}
    (BASE/'results/measurements.json').write_text(json.dumps(record,indent=2)+'\n')
    with (BASE/'results/measurements.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (BASE/'results/polynomial_metrics.json').write_text(json.dumps(poly,indent=2)+'\n')
    if any(r['status']!='PASS' for r in rows):raise SystemExit('At least one task did not pass; see recorded status.')
    print('All five specified tasks passed; no conductor-range sweep was attempted.')

if __name__=='__main__':main()
