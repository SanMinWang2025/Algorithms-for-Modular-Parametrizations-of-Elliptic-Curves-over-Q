default(nbthreads,1);

exp_emit_coefficients(F)={
  my(X=variable(F),J=variables(F)[2],v=List(),c);
  for(k=0,poldegree(F,X),for(l=0,poldegree(F,J),
    c=polcoeff(polcoeff(F,k,X),l,J);
    if(c!=0,if(type(c)!="t_INT",error("nonintegral coefficient"));
      listput(v,[k,l,Str(c)]))
  ));
  print("COEFFICIENTS_JSON ",Vec(v));
};

read("verify389_certificate.gp");
R=verify389_certificate();
print("EXPERIMENT_CHECK_COMPLETED");
quit
