\\ Exact certificate for the Yang-pair example of Section 9.
\\ Version 2026-09-08. Tested with PARI/GP 2.15.2.
\\ Usage: gp -q verify46_yang_certificate.gp
\\ No external input data or numerical recognition are used.
\\ The modular-unit transformation and cusp-order formulas are explained
\\ in Section 9. This script checks their arithmetic consequences and
\\ the finite expansion certificates. The X constant is -19/2.

gh46_unit(gs, es, a, n) =
{
  my(q='q, v=0, s=0, u=1+O(q^n), r);
  for(i=1, #gs,
    r=(a*gs[i])%46;
    s+=es[i]*((a*gs[i])\46);
    v+=es[i]*(r^2/92-r/2+46/12);
    forstep(k=r, n-1, 46, u*=(1-q^k)^es[i]);
    forstep(k=46-r, n-1, 46, u*=(1-q^k)^es[i])
  );
  if(denominator(v)!=1, error("Nonintegral q order"));
  (-1)^s*q^v*u
};

gh46_cusp_order(gs, es, a, delta) =
{
  sum(i=1, #gs, my(t=frac(a*gs[i]/delta));
    es[i]*(t^2-t+1/6))*delta/2
};

verify46_yang_certificate() =
{
  my(q='q, n=240, X, Y, Psi, P, Q, xe, res);
  my(ga=[1,14,15,16,17,18,5,6,7,8,9,22]);
  my(ea=[1,1,1,1,1,1,-1,-1,-1,-1,-1,-1]);
  my(gb=[16,21,2,7], eb=[1,1,-1,-1]);
  my(ds=[1,2,23]);
  for(k=1, #ds, for(i=1, 11,
    if(gh46_cusp_order(ga,ea,2*i-1,ds[k])!=0 ||
       gh46_cusp_order(gb,eb,2*i-1,ds[k])!=0,
       error("Unexpected cusp order"))
  ));
  print("PASS: summand cusp orders vanish for delta = 1, 2, 23");
  X=sum(i=1,11,gh46_unit(ga,ea,2*i-1,n))/2-19/2;
  Y=sum(i=1,11,gh46_unit(gb,eb,2*i-1,n))-2*X-19;
  if(valuation(X,q)!=-6 || valuation(Y,q)!=-7,
    error("Incorrect poles at infinity"));
  print("PASS: pole orders at infinity = 6, 7");
  Psi=X^7+8*X^6-26*Y*X^5-(22*Y^2+184*Y)*X^4
      -(23*Y^3+115*Y^2)*X^3-(12*Y^4+138*Y^3)*X^2
      -(5*Y^5+46*Y^4)*X-Y^6-23*Y^5;
  if(Psi!=0 || valuation(Psi,q)<=84,
    error("Yang-pair relation failed its bound 84"));
  print("PASS: Psi46(X,Y) = ",Psi,"; certificate bound = 84");
  P=X^4*(8*Y-1341)+X^3*(12*Y^2-2278*Y-25484)
    +X^2*(12*Y^3-1482*Y^2-30222*Y-114264)
    +X*(4*Y^4-541*Y^3-16698*Y^2-76176*Y)
    -74*Y^4-4393*Y^3-42849*Y^2;
  Q=-387*X^4+X^3*(4*Y^2-275*Y-6785)
    +X^2*(-54*Y^2-3726*Y-28566)
    +X*(24*Y^3-1311*Y^2-9522*Y)
    +12*Y^4+69*Y^3-4761*Y^2;
  xe=elltaniyama(ellinit([1,-1,0,-10,-12]),250)[1];
  xe=subst(xe,variable(xe),q);
  res=P-xe*Q;
  if(res!=0 || valuation(res,q)<=62,
    error("Rational expression failed its bound 62"));
  if(valuation(Q,q)!=-32 || polcoeff(Q,-32,q)!=4,
    error("Denominator nonvanishing check failed"));
  print("PASS: P1-x*Q1 = ",res,"; certificate bound = 62");
  print("PASS: Q1 = 4*q^(-32) + O(q^(-31)), hence Q1 is nonzero");
  print("All Section 9 Yang-pair certificate checks passed.");
  1
};

verify46_yang_certificate();
