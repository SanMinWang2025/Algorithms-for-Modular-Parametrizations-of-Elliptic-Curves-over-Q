\\ Exact arithmetic checks for the 91b1 polynomial in Section 3.
\\ Version 2026-09-08. Tested with PARI/GP 2.15.2.
\\ Usage: gp -q verify91b1_polynomial.gp
\\ Scope: primitive, irreducible, leading coefficient; this does not
\\ independently identify the polynomial with the stated modular fibre.

verify91b1_polynomial() =
{
  my(t='t, f);
  f=2^15*5^11*991^3*16572269011^3
    -2^9*3^4*5^10*23*40341091849*788088043784206924489867*t
    +5^6*248698909*269818358221989089513089057757*t^2
    -2^7*3^4*5^4*49633*5413524016643*t^3+2^20*t^4;
  if(content(f)!=1 || poldegree(f)!=4 || pollead(f)!=2^20,
    error("Polynomial normalization failed"));
  if(!polisirreducible(f), error("Polynomial is reducible"));
  print("PASS: content 1, degree 4, leading coefficient 2^20, irreducible");
  print("The monic minimal polynomial of every root is f/2^20.");
  print("Its roots are not algebraic integers.");
  1
};

verify91b1_polynomial();
