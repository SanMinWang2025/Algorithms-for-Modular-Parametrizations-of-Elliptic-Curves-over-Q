\\ Small construction entry point; no precomputed F11 coefficients.
\\ Usage: read("construct_and_verify11.gp"); F=construct_and_verify11();
\\ The curve is 11a1, with degree-one normalized parametrization X0(11)->E.
\\ Tested with PARI/GP 2.15.2. All coefficient arithmetic is exact.

construct_and_verify11() =
{
  my(E=ellinit([0,-1,1,-10,-20]), q='exp11q, X='exp11X, J='exp11J);
  my(K=12,L=2,d=1,mu=12,R=39, B=48, v=-26, n=100);
  my(t=getwalltime());
  my(Ta=elltaniyama(E,n),xq,jq,E4,E6,series,A,ker,h,F,res);
  xq=subst(Ta[1],variable(Ta[1]),q);
  E4=Ser(vector(n+2,i,if(i==1,1,240*sigma(i-1,3))),q);
  E6=Ser(vector(n+2,i,if(i==1,1,-504*sigma(i-1,5))),q);
  jq=1728*E4^3/(E4^3-E6^2);
  series=vector(R,i,xq^((i-1)\3)*jq^((i-1)%3));
  A=matrix(B-v+1,R,i,k,polcoeff(series[k],v+i-1,q));
  print("STAGE_MS q_and_matrix ",getwalltime()-t);t=getwalltime();
  ker=matker(A);
  if(matsize(ker)[2]!=1,error("Expected a one-dimensional certified kernel"));
  h=ker[,1];h*=denominator(h);h/=content(h);
  if(h[37]<0,h=-h);
  F=sum(i=1,R,h[i]*X^((i-1)\3)*J^((i-1)%3));
  print("STAGE_MS linear_algebra_and_normalization ",getwalltime()-t);
  t=getwalltime();
  res=sum(i=1,R,h[i]*series[i]);
  if(valuation(res,q)<=B || serprec(res,q)<=B,
     error("Finite q certificate failed"));
  if(poldegree(F,X)!=12 || poldegree(F,J)!=2,
     error("Unexpected bidegree"));
  print("STAGE_MS coefficient_certificate ",getwalltime()-t);
  print("PASS: F11 constructed from scratch; kernel dimension 1");
  print("PASS: bidegree (12,2), certificate bound 48, residual ",res);
  \\ Existence of a relation in these bounds, the full finite certificate,
  \\ and kernel dimension one identify F as the minimal relation:
  \\ a proper vanishing factor would give another independent kernel vector.
  F
};
