# Experimental supplement: fixed validation tasks

This supplement accompanies a proposed replacement for Section 2.4 of
`sanminwang10.tex`. It connects selected examples with specific mathematical
questions and records the scope and measured cost of the available checks.
It is a validation collection, not a conductor survey or an algorithm race.

## Integrating the text

Replace the entire subsection **Implementation and experimental information**
in the latest manuscript with `section2_4_experimental_revision.tex`, stopping
before Section 3. The replacement retains `subsec:experiments` and
`tab:construction-resources`. It uses the manuscript's existing `booktabs`
and `hyperref` packages and introduces no new bibliography keys.

The main manuscript's supplementary-material statement should also list this
experimental supplement and its two new scripts,
`construct_and_verify11.gp` and `run_experiment_checks.py`. Publish the bundle
at a fixed repository revision or archived release before referring to such
a revision in the manuscript. This bundle does not assert that these new
files have already been uploaded to the author's GitHub repository.

## What each check establishes

| Task | Entry point | Scope |
|---|---|---|
| 11a1 | `construct_and_verify11.gp` | Constructs the entire relation from exact curve expansions; a 75 by 39 coefficient matrix has kernel dimension one; the finite certificate uses bound 48. No precomputed relation is loaded. |
| 38a1 | `verify38_certificate.gp` | Checks the embedded complete relation, its irreducibility certificate, its leading coefficient, and positivity of the quartic; checks the exact series beyond the global bound 1440. The geometric argument in Section 4 then proves existence of non-CM zeros. |
| 389a1 | `verify389_certificate.gp` | Checks the embedded specialization, algebraic pairing, the exact analytic root enclosure, and a principal-divisor certificate for the selected 65-point sum. Its interpretation as the specified modular semi-trace assumes the full coordinate relation and the normalization in Section 7. |
| 46a1 | `verify46_yang_certificate.gp` | Constructs the Yang-pair expansions and checks its relation, the rational coordinate identity, and nonvanishing of the denominator. This is not the Section 6 branch-fibre computation. |
| 91b1 | `verify91b1_polynomial.gp` | Checks that the displayed quartic is primitive, irreducible, and has leading coefficient 2^20. This check does not certify its assignment to the displayed fibre. |

The full finite-expansion certificate for F389 and the complete 46a1
branch-value fibre certificates are **not supplied by these checks**. A PASS
is restricted to the checks above. The polynomial degrees and modular
degrees used in the pole bounds are mathematical inputs described in the
article; this collection does not re-prove all background modularity facts.

## Run the GP checks directly

All five checks passed with PARI/GP 2.15.2 in the recorded run. The older
header in the 389a1 script mentions 2.15.4; the recorded run also establishes
compatibility of these particular checks with 2.15.2. No timing equality or
compatibility with every GP version is asserted.

Change into the `checks` directory, then start a fresh GP session:

```sh
gp -fq -s 256000000
```

At the GP prompt, run a desired check:

```gp
default(nbthreads,1);
read("construct_and_verify11.gp");
F = construct_and_verify11();
```

For 38a1 or 389a1, use a fresh session and the corresponding two commands:

```gp
read("verify38_certificate.gp");
R = verify38_certificate();
```

```gp
read("verify389_certificate.gp");
R = verify389_certificate();
```

The other two files call their checking functions when loaded:

```gp
read("verify46_yang_certificate.gp");
```

```gp
read("verify91b1_polynomial.gp");
```

These scripts embed the required coefficient data. The small reconstruction
uses the curve equation and PARI's `elltaniyama`; it does not load F11 from
the accompanying JSON file. The irreducibility conclusion follows from the
one-dimensional certified kernel: a proper vanishing factor would provide
another independent vector within the same degree bounds.

## Repeat the recorded measurements

On Linux, with Python 3.9 or later and PARI/GP installed:

```sh
cd checks
python3 run_experiment_checks.py --gp /path/to/gp
```

Use `--timeout 300` to set the limit in seconds for each task (300 is the
default). The tasks run sequentially. Make a copy of the bundle before
rerunning if you wish to preserve the shipped records: a run rewrites files
under `results` and the canonical coefficient files under `data`.

The runner starts a fresh GP process for each task, ignores the user's GP
configuration with `-f`, sets `nbthreads=1`, and requests a 256,000,000-byte
initial PARI stack. Process wall time includes startup, input parsing,
verification and output. Linux `os.wait4` supplies per-process user CPU,
system CPU and maximum resident set size; `ru_maxrss` is in KiB. The wall
clock is polled every 0.01 seconds, so the article reports durations below
0.1 seconds as `<0.1`. Initial stack size is not a peak-memory measurement.

The saved run was a single run per task on Linux x86-64 with an AMD EPYC
9V74 processor and PARI/GP 2.15.2. Cache state and unrelated host activity
were not controlled. The JSON record contains the executable hash and
environment details. These are measurements of those runs, not guaranteed
runtime requirements.

| Task | Wall time (s) | Peak RSS (MiB) | Status |
|---|---:|---:|---|
| Construct and certify F11 | <0.1 | 21.1 | PASS |
| Load and certify F38 | 11.67 | 197.7 | PASS |
| Check the 389a1 semi-trace certificate | 0.35 | 21.1 | PASS |
| Construct and check the 46a1 Yang-pair identities | <0.1 | 21.1 | PASS |
| Check the 91b1 polynomial | <0.1 | 21.1 | PASS |

The 389a1 measurement is **not** a measurement of constructing or certifying
the complete F389 relation. The timing figures do not resolve the meaning
of the original 6.1 TB or 120-hour reports.

The F11 transcript also records internal stage times in integer milliseconds.
The stages combine expansion and matrix assembly, linear algebra and
normalization, and the coefficient check, respectively. Their small values,
including zero milliseconds, should not be used for a scaling claim; zero
means below that timer's resolution. No independent bivariate factorization
stage is needed for this one-dimensional kernel.

The runner records PASS, FAILED, or TIMEOUT and retains the transcript.
It checks GP error markers as well as the exit code because an interpreter
may return a zero exit code after a script error. A killed process is not
classified as an out-of-memory result without external evidence. An
unattempted task has no success claim and is not interpreted as an empty
mathematical answer.

## Canonical relation files

`data/F11_canonical.json` and `data/F38_canonical.json` contain complete
certified polynomials. Each is an uncompressed ASCII/UTF-8 JSON array of
triples `[k,l,"c"]` encoding the nonzero coefficient of X^k J^l. The array
is sorted by increasing `(k,l)`, has no spaces or final newline, and stores
coefficients as signed decimal strings. Integer content is removed and the
last coefficient in that order is positive. Maximum digit counts exclude
the minus sign.

| Relation | mu | d | K | L | r | Nonzero terms | Maximum digits | Bytes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| F11 | 12 | 1 | 12 | 2 | 1 | 37 | 22 | 841 |
| F38 | 60 | 6 | 60 | 12 | 1 | 706 | 125 | 65449 |

These two outputs do not establish a growth law or a relative size advantage
over a classical modular polynomial. In particular, no classical polynomial
was encoded or benchmarked in this experiment.

## Rectangular counts for 389a1

With K=390, L=80, d=40, and mu=390, the rectangle has 31,671 formal unknown
coefficients. The initial choice M=R+20=31,691 gives 32,552 coefficient rows
from q^(-860) through q^M. Full certification at the stated sufficient bound
B=62,400 checks 63,261 coefficient positions from q^(-860) through q^62,400,
inclusively. These counts are not matrix ranks, independent equation counts,
or resource measurements. Checking a supplied relation need not rebuild its
construction matrix; the actual cost of full F389 verification remains to be
measured.

## Data provenance and integrity

The four pre-existing verifiers come from the manuscript's earlier
verification supplement; the F11 construction and the measurement runner
are new to this experimental supplement. Embedded 38a1 and 389a1 polynomial
data derive from the author's archived notebook data. The manuscript points
to the following fixed source revision:

https://github.com/SanMinWang2025/Algorithms-for-Modular-Parametrizations-of-Elliptic-Curves-over-Q/tree/720e2ddf35f603d09722fa2890b8ce37d6716d66

`SHA256SUMS` identifies the exact files shipped in this supplement, including
the measured scripts, transcripts, canonical coefficients, and proposed
LaTeX text. Check it from this directory with:

```sh
sha256sum -c SHA256SUMS
```

The driver was adjusted after the measurement to capture GP version text
from either output stream and to include a timestamp and polling metadata.
The same GP executable supplied the version recorded in the shipped JSON;
the GP checking scripts and their arithmetic were unchanged. The recorded
times refer to the five completed checking processes, not a later rerun.
